/*
 * Implementation for AexChromosome class
 */

#include "aex_chromosome.hh"
#include <cassert>
#include <algorithm>
#include <set>
#include <iterator> // for std::advance
#include <cstdlib> // for std::rand
#include <vector>

//////////////////////////////////////////////////////////////////////////////
// Generate a completely random permutation from a list of cities
AexChromosome::AexChromosome(const Cities* cities_ptr)
    : ClimbChromosome(cities_ptr)
{
    assert(is_valid());
}

//////////////////////////////////////////////////////////////////////////////
// Clean up as necessary
AexChromosome::~AexChromosome()
{
    assert(is_valid());
}

//////////////////////////////////////////////////////////////////////////////
// Return a pair of offsprings by recombining with another chromosome
// Note: this method allocates memory for the new offsprings
std::pair<AexChromosome*, AexChromosome*>
AexChromosome::recombine(AexChromosome* other)
{
  assert(is_valid());
  assert(other->is_valid());

  // Make children:
  auto child1 = create_crossover_child(this, other);
  auto child2 = create_crossover_child(other, this);

  return std::make_pair(child1, child2);
}

//////////////////////////////////////////////////////////////////////////////
// For two given pairs, returns a child that is created using
// alternating edges crossover.
AexChromosome*
AexChromosome::create_crossover_child(AexChromosome* p0,
                                      AexChromosome* p1) const{
    auto child = this->clone();
    unsigned int order_size = child->order_.size();

    child->order_.clear();
    child->order_.push_back(p0->order_[0]);
    bool next_parent = 1;
    Cities::permutation_t parent_order;
    unsigned int last_index_written = 0;
    std::set<unsigned int> remaining_values;
    for (unsigned int i = 0; i != order_size; i++){
        remaining_values.insert(i);
    }

    while (child->order_.size() < order_size){

        if (next_parent){
            parent_order = p1->order_;
        }
        else{parent_order = p0->order_;}

        auto it_of_other = std::find(parent_order.begin(), parent_order.end(), child->order_[last_index_written]);
        if (it_of_other == parent_order.end()-1 || remaining_values.find(*it_of_other) == remaining_values.end()){
            // if value is already in child or the iterator is out of bounds
            // find random from remaining values
            auto set_it = remaining_values.begin();
            std::advance(set_it, std::rand() % order_size);
            child->order_.push_back(*(set_it));
            remaining_values.erase(*(set_it));

        } 
        else{
            child->order_.push_back(*(it_of_other+1));
            remaining_values.erase(*(it_of_other+1));
        }
        


        next_parent = !next_parent;
        last_index_written++;
    }
    assert(child->is_valid());
    return child;
}