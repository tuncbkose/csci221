/*
 * aex_chromosome.hh
 * Represents the interface of Alternating Edges Crossover (AEX)
 * Chromosome, built on top of ClimbChromosome class.
 */

#pragma once

#include "climb_chromosome.hh"

class AexChromosome : public ClimbChromosome{
    protected:
        // Disable public copying of objects for polymorphism:
        AexChromosome(const AexChromosome&) = default;
        AexChromosome(AexChromosome&&) = default;
        AexChromosome& operator=(const AexChromosome&) = default;
        AexChromosome& operator=(AexChromosome&&) = default;

    public:
        // Creation method for new AexChromosome. Saves a copy of the cities and
        // generates a completely random permutation from a list of cities.
        AexChromosome(const Cities*);

        // Polymorphic creation method from an existing AexChromosome.
        // This method allocates memory for the newly created chromosome.
        // It is the caller's responsibility to free this memory.
        virtual AexChromosome* clone() const
        {
            return new AexChromosome(*this);
        }

        // Clean up as necessary
        virtual ~AexChromosome();

        // Return a pair of offsprings by recombining with another chromosome
        // Note: this method allocates memory for the new offsprings
         // It is the caller's responsibility to free this memory.
        virtual std::pair<AexChromosome*, AexChromosome*> recombine(AexChromosome*);
    protected:
        // For an ordered set of parents, return a child using 
        // alternating edges crossover (AEX).
        virtual AexChromosome*
        create_crossover_child(AexChromosome* parent1,
                               AexChromosome* parent2) const;
};